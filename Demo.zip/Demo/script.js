// LocalStorage debug version
const form = document.getElementById('todo-form') || document.getElementById('form');
const input = document.getElementById('todo-input') || document.getElementById('input');
const list = document.getElementById('todo-list') || document.getElementById('list');
const empty = document.getElementById('empty');

const STORAGE_KEY = 'simple_todos_v1';
let todos = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(todos));
  render();
}

function createTodo(text) {
  return { id: Date.now().toString(), text: text.trim(), done: false, createdAt: new Date().toISOString() };
}

if (!form || !input || !list) {
  console.error('Missing expected DOM elements. Form/input/list IDs must match those in HTML.');
  alert('Missing DOM elements. Check console.');
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const val = input.value;
  console.log('Try add:', val);
  if (!val || !val.trim()) { alert('Enter a task'); return; }
  todos.unshift(createTodo(val));
  input.value = '';
  save();
  alert('Added locally — check the list');
});

function toggleDone(id) {
  todos = todos.map(t => t.id === id ? {...t, done: !t.done } : t);
  save();
}
function removeTodo(id) { todos = todos.filter(t => t.id !== id); save(); }

function startEdit(id, textEl) {
  const todo = todos.find(t => t.id === id);
  if (!todo) return;
  const inputEl = document.createElement('input');
  inputEl.type = 'text';
  inputEl.value = todo.text;
  inputEl.className = 'edit-input';
  textEl.replaceWith(inputEl);
  inputEl.focus();
  inputEl.addEventListener('blur', () => {
    const newVal = inputEl.value.trim();
    if (newVal) todos = todos.map(t => t.id === id ? {...t, text: newVal} : t);
    save();
  });
  inputEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') inputEl.blur(); if (e.key === 'Escape') save(); });
}

function render() {
  if (!list) return;
  list.innerHTML = '';
  if (!todos.length) {
    if (empty) empty.style.display = 'block';
    list.innerHTML = '<li class="item">No tasks</li>';
    return;
  } else if (empty) empty.style.display = 'none';

  todos.forEach(todo => {
    const li = document.createElement('li');
    li.className = 'todo-item' + (todo.done ? ' done' : '');
    const left = document.createElement('div'); left.className = 'left';
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !!todo.done; cb.addEventListener('change', () => toggleDone(todo.id));
    const text = document.createElement('div'); text.className = 'text'; text.textContent = todo.text;
    left.append(cb, text);
    const actions = document.createElement('div'); actions.className = 'actions';
    const editBtn = document.createElement('button'); editBtn.className = 'icon-btn ghost'; editBtn.textContent = 'Edit'; editBtn.addEventListener('click', () => startEdit(todo.id, text));
    const delBtn = document.createElement('button'); delBtn.className = 'icon-btn danger'; delBtn.textContent = 'Delete'; delBtn.addEventListener('click', () => { if (confirm('Delete?')) removeTodo(todo.id); });
    actions.append(editBtn, delBtn);
    li.append(left, actions);
    list.appendChild(li);
  });
}

render();
